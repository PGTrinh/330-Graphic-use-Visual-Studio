﻿#include <GLFW\glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <vector>
#include <windows.h>
#include <time.h>
#include <random>

using namespace std;

const float DEG2RAD = 3.14159 / 180;

void processInput(GLFWwindow* window);

enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE};
enum ONOFF { ON, OFF };


class Brick
{
public:
	float red, green, blue;
	float x, y, width;
	int life;		// track the brick's life
	BRICKTYPE brick_type;
	ONOFF onoff;

	Brick(BRICKTYPE bt, float xx, float yy, float ww, float rr, float gg, float bb)
	{
		brick_type = bt; x = xx; y = yy, width = ww; red = rr, green = gg, blue = bb;
		onoff = ON;
		life = 2; //set life to 2
	};

	void drawBrick()
	{
		if (onoff == ON)
		{
			double halfside = width / 2;

			glColor3d(red, green, blue);
			glBegin(GL_POLYGON);

			glVertex2d(x + halfside, y + halfside);
			glVertex2d(x + halfside, y - halfside);
			glVertex2d(x - halfside, y - halfside);
			glVertex2d(x - halfside, y + halfside);

			glEnd();
		}
	}
};


class Circle
{
public:
	float red, green, blue;
	float radius;
	float x;
	float y;
	float speed = 0.01;
	int direction; // 1=up 2=right 3=down 4=left 5 = up right   6 = up left  7 = down right  8= down left
	ONOFF onoff;


	Circle(double xx, double yy, double rr, int dir, float rad, float r, float g, float b)
	{
		x = xx;
		y = yy;
		radius = rr;
		red = r;
		green = g;
		blue = b;
		radius = rad;
		direction = dir;
		onoff = ON;
	}
	void CheckCollision(Circle* otherCircle)
	{
		if (onoff == ON && otherCircle->onoff == ON)
		{
			float dx = x - otherCircle->x;
			float dy = y - otherCircle->y;
			float distance = sqrt(dx * dx + dy * dy);

			if (distance <= radius + otherCircle->radius)
			{
				onoff = OFF;
				otherCircle->onoff = OFF;
			}
		}
	}
	void CheckCollision(Brick* brk)
	{
		if ((x > brk->x - brk->width && x <= brk->x + brk->width) && (y > brk->y - brk->width && y <= brk->y + brk->width))
		{
			//REFLECTIVE BRICK's PROPERTIES
			if (brk->brick_type == REFLECTIVE)
			{
				if (direction == 1) direction = 3;   // Change up to down
				else if (direction == 2) direction = 4;   // Change right to left
				else if (direction == 3) direction = 1;   // Change down to up
				else if (direction == 4) direction = 2;   // Change left to right
				else if (direction == 5) direction = 8;   // Change up-right to down-left
				else if (direction == 6) direction = 7;   // Change up-left to down-right
				else if (direction == 7) direction = 6;   // Change down-right to up-left
				else if (direction == 8) direction = 5;   // Change down-left to up-right

				// Adjust position slightly to prevent getting stuck
				x += 0.01 * (direction == 2 || direction == 5 || direction == 7);
				y += 0.01 * (direction == 1 || direction == 5 || direction == 6);
			}

			//DESTRUCTABLE BRICK's PROPERTIES
			if (brk->brick_type == DESTRUCTABLE)
			{
				brk->life--;
				if (brk->life <= 0) //WHEN life is 0 turn the brick OFF (MAKE IT GONE)
				{
					brk->onoff = OFF;
					if (direction == 1) direction = 3;   // Change up to down
					else if (direction == 2) direction = 4;   // Change right to left
					else if (direction == 3) direction = 1;   // Change down to up
					else if (direction == 4) direction = 2;   // Change left to right
					else if (direction == 5) direction = 8;   // Change up-right to down-left
					else if (direction == 6) direction = 7;   // Change up-left to down-right
					else if (direction == 7) direction = 6;   // Change down-right to up-left
					else if (direction == 8) direction = 5;   // Change down-left to up-right

					// Adjust position slightly to prevent getting stuck
					x += 0.01 * (direction == 2 || direction == 5 || direction == 7);
					y += 0.01 * (direction == 1 || direction == 5 || direction == 6);
				}
	
			}

			if (direction <= 4) // Only reverse direction for 1-4
			{
				direction = (direction + 2) % 4 + 1;  // Reverse direction
			}
			else // For directions 5-8, reverse both components
			{
				direction = (direction + 4) % 8 + 1;  // Reverse direction
			}

		}
	}

	int GetRandomDirection()
	{
		return (rand() % 8) + 1;
	}

	void MoveOneStep()
	{
		if (direction == 1 || direction == 5 || direction == 6)  // up
		{
			if (y > -1 + radius)
			{
				y -= speed;
			}
			else
			{
				direction = GetRandomDirection();
			}
		}
		else if (direction == 3 || direction == 7 || direction == 8)  // down
		{
			if (y < 1 - radius) {
				y += speed;
			}
			else
			{
				direction = GetRandomDirection();
			}
		}

		if (direction == 2 || direction == 5 || direction == 7)  // right
		{
			if (x < 1 - radius)
			{
				x += speed;
			}
			else
			{
				direction = GetRandomDirection();
			}
		}

		if (direction == 4 || direction == 6 || direction == 8)  // left
		{
			if (x > -1 + radius) {
				x -= speed;
			}
			else
			{
				direction = GetRandomDirection();
			}
		}
	}
	

	void DrawCircle()
	{
		//
		if (onoff == ON)
		{
			glColor3f(red, green, blue);
			glBegin(GL_POLYGON);
			for (int i = 0; i < 360; i++) {
				float degInRad = i * DEG2RAD;
				glVertex2f((cos(degInRad) * radius) + x, (sin(degInRad) * radius) + y);
			}
			glEnd();
		}

	}
};


vector<Circle> world;


int main(void) {
	srand(time(NULL));

	if (!glfwInit()) {
		exit(EXIT_FAILURE);
	}
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
	GLFWwindow* window = glfwCreateWindow(480, 480, "Random World of Circles", NULL, NULL);
	if (!window) {
		glfwTerminate();
		exit(EXIT_FAILURE);
	}
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1);


	// brick position and colors
	Brick brick1(REFLECTIVE, -1.0, 1.0, 0.2, 1, 0, 0);
	Brick brick2(REFLECTIVE, -0.8, -1.0, 0.2, 1, 0.5, 0);
	Brick brick3(REFLECTIVE, -0.6, 1.0, 0.2, 1, 1, 0);
	Brick brick4(REFLECTIVE, -0.4, -1.0, 0.2, 0, 1, 0);
	Brick brick5(REFLECTIVE, -0.2, 1.0, 0.2, 0, 1, 1);
	Brick brick6(REFLECTIVE, -0.0, -1.0, 0.2, 0, 0, 1);
	Brick brick7(REFLECTIVE, 0.2, 1.0, 0.2, 0.5, 0, 1);
	Brick brick8(REFLECTIVE, 0.4, -1.0, 0.2, 1, 0, 1);
	Brick brick9(REFLECTIVE, 0.6, 1.0, 0.2, 1, 0, 0.5);
	Brick brick10(REFLECTIVE, 0.8, -1.0, 0.2, 1, 1, 1);
	Brick brick11(REFLECTIVE, 1.0, 1.0, 0.2, 1, 0, 0);
	Brick brick12(DESTRUCTABLE, -1.0, 0.0, 0.2, 0, 1, 0);
	Brick brick13(DESTRUCTABLE, -0.5, 0.0, 0.2, 0, 1, 1);
	Brick brick14(DESTRUCTABLE,  0.0, -0.5, 0.2, 0, 0, 1);
	Brick brick15(DESTRUCTABLE, 0.5, 0.0, 0.2, 0.5, 0, 1);
	Brick brick16(DESTRUCTABLE, 1.0, 0.0, 0.2, 1, 0, 1);
	Brick brick17(DESTRUCTABLE, 0.0, 0.5, 0.2, 1, 1, 1);
	Brick brick18(DESTRUCTABLE, 0.5, 0.0, 0.2, 1, 0, 0);




	while (!glfwWindowShouldClose(window)) {
		//Setup View
		float ratio;
		int width, height;
		glfwGetFramebufferSize(window, &width, &height);
		ratio = width / (float)height;
		glViewport(0, 0, width, height);
		glClear(GL_COLOR_BUFFER_BIT);

		processInput(window);

		//Movement
		for (int i = 0; i < world.size(); i++)
		{
			world[i].CheckCollision(&brick1);
			world[i].CheckCollision(&brick2);
			world[i].CheckCollision(&brick3);
			world[i].CheckCollision(&brick4);
			world[i].CheckCollision(&brick5);
			world[i].CheckCollision(&brick6);
			world[i].CheckCollision(&brick7);
			world[i].CheckCollision(&brick8);
			world[i].CheckCollision(&brick9);
			world[i].CheckCollision(&brick10);
			world[i].CheckCollision(&brick11);
			world[i].CheckCollision(&brick12);
			world[i].CheckCollision(&brick13);
			world[i].CheckCollision(&brick14);
			world[i].CheckCollision(&brick15);
			world[i].CheckCollision(&brick16);
			world[i].CheckCollision(&brick17);
			world[i].CheckCollision(&brick18);

			world[i].MoveOneStep();
			world[i].DrawCircle();

			//check collision of circle
			for (int i = 0; i < world.size(); i++)
			{
				for (int j = i + 1; j < world.size(); j++)
				{
					world[i].CheckCollision(&world[j]);
				}

			}
			//clear screen if collide
			glClear(GL_COLOR_BUFFER_BIT);

			//if the circle is ON (active), render will redraw it
			for (int i = 0; i < world.size(); i++)
			{
				if (world[i].onoff == ON)
				{
					world[i].DrawCircle();
				}
			}
		}
		
		//call render to draw the brick
		brick1.drawBrick();
		brick2.drawBrick();
		brick3.drawBrick();
		brick4.drawBrick();
		brick5.drawBrick();
		brick6.drawBrick();
		brick7.drawBrick();
		brick8.drawBrick();
		brick9.drawBrick();
		brick10.drawBrick();
		brick11.drawBrick();
		brick12.drawBrick();
		brick13.drawBrick();
		brick14.drawBrick();
		brick15.drawBrick();
		brick16.drawBrick();
		brick17.drawBrick();
		brick18.drawBrick();


		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwDestroyWindow(window);
	glfwTerminate;
	exit(EXIT_SUCCESS);
}


void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	static bool spaceKeyPressed = false;
	if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS && !spaceKeyPressed)
	{
		spaceKeyPressed = true;
		double r, g, b;
		r = static_cast<float>(rand()) / RAND_MAX;
		g = static_cast<float>(rand()) / RAND_MAX;
		b = static_cast<float>(rand()) / RAND_MAX;
		Circle B(0, 0, 0.2, 1, 0.05, r, g, b);
		B.direction = B.GetRandomDirection();
		world.push_back(B);
	}
	else if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_RELEASE)
	{
		spaceKeyPressed = false;
	}
}