/*
    Author: Philip Trinh
    SNHU - CS330 : 5 - 5 Texturing Obj 3D Scene
    7/27/2023
*/ 

#include <iostream> // cout, cerr
#include <cstdlib> // EXIT_FAILURE
#include <GL/glew.h> // GLEW library
#include <GLFW/glfw3.h> // GLFW library
#define STB_IMAGE_IMPLEMENTATION //preprocessor modifies the header file into a .cpp file
#include <stb_image.h> // Image loading library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "camera.h" // Include camera class

using namespace std; // Standard namespace

/* Shader program Macro -create and control the behavior of shaders*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Trinh 5-5 Texturing Obj 3D Scene"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao; // Handle for the vertex array object
        GLuint vbos[2]; // Handles for the vertex buffer objects [2] to declare 2 elements
        GLuint nIndices; // Number of indices of the mesh
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Mesh data
    GLMesh gPyramidMesh;
    GLMesh gCylinderMesh;
    GLMesh gConeMesh;
    GLMesh gPlaneMesh;
    GLMesh gCubeMesh;
    // Textures
    GLuint gDeskTextureId;
    GLuint gStylusHeadTextureId;
    GLuint gStylusBodyTextureId;
    GLuint gWhitePlasticTextureId;
    GLuint gIpadScreenTextureId;
    GLuint gIphoneTextureId;
    GLuint gKeyboardTextureId;
    GLuint gStarbuckTextureId;
    // Shader programs
    GLuint gProgramId;

    // camera
    Camera gCamera(glm::vec3(-2.0f, 6.0f, 15.0f));

    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    // View mode
    bool gOrthoView = false;
}

/*
 * User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreatePyramidMesh(GLMesh& mesh);
void UCreateCubeMesh(GLMesh& mesh, float frontHeight = 0.5f, float backHeight = 0.5f);
void UCreateCylinderMesh(GLMesh& mesh);
void UCreateConeMesh(GLMesh& mesh);
void UCreatePlaneMesh(GLMesh& mesh, float frontHeight = 0.5f, float backHeight = 0.5f);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId, bool flipImage = true);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);

/* Vertex Shader Source Code */
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0
    layout(location = 1) in vec3 normal; // Normal data from Vertex Attrib Pointer 1
    layout(location = 2) in vec2 textureCoordinate; // Texture data from Vertex Attrib Pointer 2

    out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
    out vec3 vertexNormal; // For outgoing normals to fragment shader
    out vec2 vertexTextureCoordinate; // For outgoing texture coordinate

    // Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices to clip coordinates
        vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)
        vertexNormal = mat3(transpose(inverse(model))) * normal; // Gets normal vectors in world space only and exclude normal translation properties
        vertexTextureCoordinate = textureCoordinate; // Gets texture coordinate
    }
);

/* Fragment Shader Source Code */
const GLchar* fragmentShaderSource = GLSL(440,
    in vec3 vertexFragmentPos; // For incoming fragment position
    in vec3 vertexNormal; // For incoming normals
    in vec2 vertexTextureCoordinate; // For incoming texture coordinate

    out vec4 fragmentColor; // For outgoing cube color to the GPU

    uniform sampler2D uTexture; // Useful when working with multiple textures
    uniform vec2 uvScale;

    void main()
    {
        // Texture holds the color to be used for all three components
        vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

        // Output the texture color as the fragment color
        fragmentColor = textureColor;
    }
);



// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}

int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
    {
        return EXIT_FAILURE;
    }

    // Create the scene meshes
    // -----------------------
    UCreatePyramidMesh(gPyramidMesh);
    UCreateCubeMesh(gCubeMesh);
    UCreatePlaneMesh(gPlaneMesh);
    UCreateConeMesh(gConeMesh);
    UCreateCylinderMesh(gCylinderMesh);

    // Create the shader programs
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
    {
        cout << "Failed to create shader" << endl;
        return EXIT_FAILURE;
    }

    // Load desk texture
    const char* texFilename = "../textures/desk.png";
    if (!UCreateTexture(texFilename, gDeskTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    glUseProgram(gProgramId); // tell opengl texture unit sample belongs to
    glUniform1i(glGetUniformLocation(gProgramId, "deskTexture"), 0); // Set the texture as texture unit 0

    // Load Stylus Head texture
    texFilename = "../textures/stylushead.png";
    if (!UCreateTexture(texFilename, gStylusHeadTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    glUseProgram(gProgramId); // tell opengl texture unit sample belongs to
    glUniform1i(glGetUniformLocation(gProgramId, "StylusHeadTexture"), 0); // Set the texture as texture unit 0

    // Load Stylus body texture
    texFilename = "../textures/stylusbody.png";
    if (!UCreateTexture(texFilename, gStylusBodyTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    glUseProgram(gProgramId); // tell opengl texture unit sample belongs to
    glUniform1i(glGetUniformLocation(gProgramId, "StylusBodyTexture"), 0); // Set the texture as texture unit 0

    // Load mouse pad texture
    texFilename = "../textures/whiteplastic.png";
    if (!UCreateTexture(texFilename, gWhitePlasticTextureId, false))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    glUseProgram(gProgramId); // tell opengl texture unit sample belongs to
    glUniform1i(glGetUniformLocation(gProgramId, "WhitePlasticTexture"), 0); // Set the texture as texture unit 0

    // Load IpadScreen cube texture
    texFilename = "../textures/ipadscreen.png";
    if (!UCreateTexture(texFilename, gIpadScreenTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    glUseProgram(gProgramId); // tell opengl texture unit sample belongs to
    glUniform1i(glGetUniformLocation(gProgramId, "IpadScreenTexture"), 0); // Set the texture as texture unit 0

    // Load Iphone texture
    texFilename = "../textures/iphone.png";
    if (!UCreateTexture(texFilename, gIphoneTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    glUseProgram(gProgramId); // tell opengl texture unit sample belongs to
    glUniform1i(glGetUniformLocation(gProgramId, "IphoneTexture"), 0); // Set the texture as texture unit 0

    // Load keyboard texture
    texFilename = "../textures/keyboard.png";
    if (!UCreateTexture(texFilename, gKeyboardTextureId, false))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    glUseProgram(gProgramId); // tell opengl texture unit sample belongs to
    glUniform1i(glGetUniformLocation(gProgramId, "keyboardTexture"), 0); // Set the texture as texture unit 0

    // Load Starbuck texture
    texFilename = "../textures/starbuck.png";
    if (!UCreateTexture(texFilename, gStarbuckTextureId, false))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    glUseProgram(gProgramId); // tell opengl texture unit sample belongs to
    glUniform1i(glGetUniformLocation(gProgramId, "StarbuckTexture"), 0); // Set the texture as texture unit 0

    // Sets the background color of the window (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // Render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // Per-frame timing
        // ----------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // Input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gPyramidMesh);
    UDestroyMesh(gCylinderMesh);
    UDestroyMesh(gConeMesh);
    UDestroyMesh(gPlaneMesh);
    UDestroyMesh(gCubeMesh);

    // Release texture
    UDestroyTexture(gDeskTextureId);
    UDestroyTexture(gStylusHeadTextureId);
    UDestroyTexture(gStylusBodyTextureId);
    UDestroyTexture(gWhitePlasticTextureId);
    UDestroyTexture(gIpadScreenTextureId);
    UDestroyTexture(gIphoneTextureId);
    UDestroyTexture(gKeyboardTextureId);
    UDestroyTexture(gStarbuckTextureId);

    // Release shader program
    UDestroyShaderProgram(gProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}

// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        cout << "Failed to create GLFW window" << endl;
        glfwTerminate();
        return false;
    }
    //attach funtions to window
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        cerr << glewGetErrorString(GlewInitResult) << endl;
        return false;
    }

    // Displays GPU OpenGL version and control instructions
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl << endl;
    cout << "Keyboard input" << endl;
    cout << "W: Forward, S: Backward, A: left, S: right" << endl;
    cout << "Q: Up, E: down" << endl;
    cout << "O: Orthographic View, P: Perspective View" << endl;
    cout << "ESC: Exit" << endl << endl;
    cout << "Mouse input" << endl;
    cout << "Mouse scroll : Adjust the movement's speed" << endl;
    cout << "Mouse cursor : Paranomic view of surrounding" << endl;
    cout << "Left click : Reset view" << endl;
    cout << "Right click : Reset movement speed" << endl;
    cout << "Shift key + mouse scroll : Zoom in / out" << endl;
    cout << "Shift key + right click : Reset zoom" << endl;
    //set all function in Uinitialize to active
    return true;
}
// Process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    // Exit the program
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) { glfwSetWindowShouldClose(window, true); }

    // Keyboard movement keys
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) { gCamera.ProcessKeyboard(FORWARD, gDeltaTime); }
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) { gCamera.ProcessKeyboard(BACKWARD, gDeltaTime); }
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) { gCamera.ProcessKeyboard(LEFT, gDeltaTime); }
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) { gCamera.ProcessKeyboard(RIGHT, gDeltaTime); }
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) { gCamera.ProcessKeyboard(UP, gDeltaTime); }
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) { gCamera.ProcessKeyboard(DOWN, gDeltaTime); }

    // Switch view mode on key press O & P - between orthographic and projection views
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS && !gOrthoView)
    {
        gOrthoView = true;
        cout << "Switched to orthographic view" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS && gOrthoView)
    {
        gOrthoView = false;
        cout << "Switched to projection view" << endl;
    }
}

// window resizing and mouse position callbacks
//This function is called when the window is resized, it sets the viewport to match the new window dimensions.
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}
//This function is called when the mouse cursor moves within the window. 
//It calculates the offset of the mouse cursor position from the last known position
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }
    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;
    //takes the mouse offset as input and adjusts the camera's pitch and yaw, rotate the camera's view direction.
    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// GLFW: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    if (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS ||
        glfwGetKey(window, GLFW_KEY_RIGHT_SHIFT) == GLFW_PRESS)
    {
        cout << "Camera zoom adjusted" << endl;
        gCamera.AdjustZoom(yoffset);
    }
    else
    {
        cout << "Camera movement speed adjusted" << endl;
        gCamera.AdjustMovementSpeed(yoffset);
    }
}
// GLFW: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
        if (action == GLFW_PRESS)
        {
            cout << "Camera position reset" << endl;
            gCamera.ResetCameraPosition();
        }
        break;
    case GLFW_MOUSE_BUTTON_RIGHT:
        if (action == GLFW_PRESS &&
            (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS ||
                glfwGetKey(window, GLFW_KEY_RIGHT_SHIFT) == GLFW_PRESS))
        {
            cout << "Camera zoom reset" << endl;
            gCamera.ResetCameraZoom();
        }
        else if (action == GLFW_PRESS)
        {
            cout << "Camera movement speed reset" << endl;
            gCamera.ResetCameraSpeed();
        }
        break;
    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}
// Function called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.3f, 0.3f, 0.3f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Declare variables for rendering
    const glm::vec3 cameraPosition = gCamera.Position;
    glm::vec2 uvScale;
    glm::mat4 view,
        projection,
        scale,
        rotation,
        translation,
        model;
    GLint texWrapMode = GL_REPEAT,
        uvScaleLoc,
        viewLoc,
        projLoc,
        modelLoc;

    if (gOrthoView)
    {
        // Camera/view transformation
        view = gCamera.GetViewMatrix();
        // Creates an orthographic (2D) projection
        projection = glm::ortho(-(GLfloat)WINDOW_WIDTH * 0.01f, (GLfloat)WINDOW_WIDTH * 0.01f, -(GLfloat)WINDOW_HEIGHT * 0.01f, (GLfloat)WINDOW_HEIGHT * 0.01f, 0.1f, 100.0f);
    }
    else
    {
        // Camera/view transformation
        view = gCamera.GetViewMatrix();
        // Creates a perspective (3D) projection
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    //--------------------------------------------------------------------------------------------------------------------------
    //Objects' properties 
    
    // Desk - Plane
    //----------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gPlaneMesh.vao);

    // Set the shader to be used
    glUseProgram(gProgramId);
    // Set scale, rotation, and translation
    scale = glm::scale(glm::vec3(8.5f, 1.0f, 4.5f));
    translation = glm::translate(glm::vec3(-3.0f, 0.0f, -2.0f));
    model = translation * scale; // Creates transform matrix
    // Reference matrix uniforms from the shader program
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    modelLoc = glGetUniformLocation(gProgramId, "model");
    // Pass matrix data to the shader program's matrix uniforms
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    // Set texture scale
    uvScale = glm::vec2(1.0f, 1.0f);
    uvScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(uvScaleLoc, 1, glm::value_ptr(uvScale));
    // Bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gDeskTextureId);
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_SHORT, NULL);



    // STYLUS HEAD: Pyramid
    //-----------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gPyramidMesh.vao);
    // Set the shader to be used
    glUseProgram(gProgramId);
    // scale, rotation, and translation in x,y,z axis
    scale = glm::scale(glm::vec3((glm::vec3(0.07f, 0.35f, 0.07f))));
    rotation = glm::rotate(glm::radians(93.0f), glm::vec3(0.8f, 0.0f, 1.0f));
    translation = glm::translate(glm::vec3(-2.35f, 0.2f, -1.25f));
    model = translation * rotation * scale;    // Model matrix: transformations are applied right-to-left order
    // Reference matrix uniforms from the shader program
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    modelLoc = glGetUniformLocation(gProgramId, "model");
    // Pass matrix data to the shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    // Set texture scale
    uvScale = glm::vec2(1.0f, 1.0f);
    uvScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(uvScaleLoc, 1, glm::value_ptr(uvScale));
    // Bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gStylusHeadTextureId);
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gPyramidMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle
    


    // Stylus Body : Cylinder
    //-------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gCylinderMesh.vao);
    // Set the shader to be used
    glUseProgram(gProgramId);
    // scale, rotation, and translation in x,y,z axis 
    scale = glm::scale(glm::vec3(0.12f, 0.12f, 1.65f));
    rotation = glm::rotate(glm::radians(125.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(-1.0f, 0.2f, -2.2f));
    model = translation * rotation * scale; // Creates transform matrix
    // Reference matrix uniforms from the shader program
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    modelLoc = glGetUniformLocation(gProgramId, "model");
    // Pass matrix data to the shader program's matrix uniforms
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    // Set texture scale
    uvScale = glm::vec2(1.0f, 1.0f);
    uvScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(uvScaleLoc, 1, glm::value_ptr(uvScale));
    // Bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gStylusBodyTextureId);
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gCylinderMesh.nIndices, GL_UNSIGNED_SHORT, NULL);
    


    // Starbuck Lower Cap : Cone
    //----------------------
     // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gConeMesh.vao);
    // Set the shader to be used
    glUseProgram(gProgramId);
    // Set scale, rotation, and translation
    scale = glm::scale(glm::vec3(1.4f, 1.4f, 0.3f));
    rotation = glm::rotate(glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    translation = glm::translate(glm::vec3(1.5f, 2.9f, -4.7f));
    model = translation * rotation * scale; // Creates transform matrix
    // Reference matrix uniforms from the shader program
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    modelLoc = glGetUniformLocation(gProgramId, "model");
    // Pass matrix data to the shader program's matrix uniforms
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    // Set texture scale
    uvScale = glm::vec2(1.0f, 1.0f);
    uvScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(uvScaleLoc, 1, glm::value_ptr(uvScale));
    // Bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gWhitePlasticTextureId);
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gConeMesh.nIndices, GL_UNSIGNED_SHORT, NULL);



    // Starbuck Cup Cap: Cylinder
    //--------------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gCylinderMesh.vao);
    // Set the shader to be used
    glUseProgram(gProgramId);
    // Set scale, rotation, and translation
    scale = glm::scale(glm::vec3(1.25f, 1.25f, 0.15f));
    rotation = glm::rotate(glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    translation = glm::translate(glm::vec3(1.5f, 2.8f, -4.7f));
    model = translation * rotation * scale; // Creates transform matrix
    // Reference matrix uniforms from the shader program
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    modelLoc = glGetUniformLocation(gProgramId, "model");
    // Pass matrix data to the shader program's matrix uniforms
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    // Set texture scale
    uvScale = glm::vec2(1.0f, 1.0f);
    uvScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(uvScaleLoc, 1, glm::value_ptr(uvScale));
    // Bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gWhitePlasticTextureId);
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gCylinderMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

 
    // StarBuck Cup Body: Cylinder
    //------------------------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gCylinderMesh.vao);
    // Set the shader to be used
    glUseProgram(gProgramId);
    // Set scale, rotation, and translation
    scale = glm::scale(glm::vec3(1.2f, 1.2f, 1.3f));
    rotation = glm::rotate(glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    translation = glm::translate(glm::vec3(1.5f, 1.4f, -4.7f));
    model = translation * rotation * scale; // Creates transform matrix
    // Reference matrix uniforms from the shader program
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    modelLoc = glGetUniformLocation(gProgramId, "model");
    // Pass matrix data to the shader program's matrix uniforms
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    // Set texture scale
    uvScale = glm::vec2(1.0f, 1.0f);
    uvScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(uvScaleLoc, 1, glm::value_ptr(uvScale));
    // Bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gStarbuckTextureId);
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gCylinderMesh.nIndices, GL_UNSIGNED_SHORT, NULL);



    // IPAD SCREEN : Cube
    //----------------------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gCubeMesh.vao);
    // Set the shader to be used
    glUseProgram(gProgramId);
    // Set scale, rotation, and translation
    scale = glm::scale(glm::vec3(4.2f, 3.5f, 0.1f));
    rotation = glm::rotate(glm::radians(-45.0f), glm::vec3(6.0f, 0.0f, 0.0f));
    translation = glm::translate(glm::vec3(-4.3f, 2.6f, -5.5f));
    model = translation * rotation * scale; // Creates transform matrix
    // Reference matrix uniforms from the shader program
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    modelLoc = glGetUniformLocation(gProgramId, "model");
    // Pass matrix data to the shader program's matrix uniforms
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    // Set texture scale
    uvScale = glm::vec2(1.0f, 1.0f);
    uvScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(uvScaleLoc, 1, glm::value_ptr(uvScale));
    // Bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gIpadScreenTextureId);
    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nIndices);
    

    // IPAD KEYBOARD: Plane
    //--------------------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gPlaneMesh.vao);
    // Set the shader to be used
    glUseProgram(gProgramId);
    // Set scale, rotation, and translation
    scale = glm::scale(glm::vec3(4.25f, 6.5f, 2.0f));
    rotation = glm::rotate(glm::radians(-45.0f), glm::vec3(6.0f, 0.0f, 0.0f));
    translation = glm::translate(glm::vec3(-4.25f, 0.025f, -2.5f));
    model = translation * scale; // Creates transform matrix
    // Reference matrix uniforms from the shader program
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    modelLoc = glGetUniformLocation(gProgramId, "model");
    // Pass matrix data to the shader program's matrix uniforms
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    // Set texture scale
    uvScale = glm::vec2(1.0f, 1.0f);
    uvScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(uvScaleLoc, 1, glm::value_ptr(uvScale));
    // Bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gKeyboardTextureId);
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_SHORT, NULL);



    // Iphone : Cube
    //-----------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gCubeMesh.vao);
    // Set the shader to be used
    glUseProgram(gProgramId);
    // Set scale, rotation, and translation
    scale = glm::scale(glm::vec3(0.8f, 0.1f, 1.5f));
    rotation = glm::rotate(glm::radians(180.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    translation = glm::translate(glm::vec3(1.3f, 0.1f, -1.2f));
    model = translation * rotation * scale; // Creates transform matrix
    // Reference matrix uniforms from the shader program
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    modelLoc = glGetUniformLocation(gProgramId, "model");
    // Pass matrix data to the shader program's matrix uniforms
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    // Set texture scale
    uvScale = glm::vec2(1.0f, 1.0f);
    uvScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(uvScaleLoc, 1, glm::value_ptr(uvScale));
    // Bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gIphoneTextureId);
    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nIndices);



    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);
    glUseProgram(0);

    // GLFW: Swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow); // Flips the the back buffer with the front buffer every frame.
}
//--------------------------------------------------------------------------------------------------------------------------------------------------
// CREATE MESH SHAPES

//Cone Mesh
void UCreateConeMesh(GLMesh& mesh)
{
    // Set number of sections making up the cone
    //circle formula for circumferences divide by slices to find out how many radians per slices
    const int slices = 24;
    const float angle = 2.0f * 3.14159265358979323846f / slices;  

    const int triangleSize = 3; //set to 3 since each triangle require 3 vertices

    glm::vec3 vertex[slices + 1];

    const int numVerts = sizeof(vertex) / sizeof(vertex[0]) * 6;
    const int numIndices = slices * triangleSize;

    GLfloat verts[numVerts];
    GLushort indices[numIndices];

    for (int i = 0; i <= slices; i++)
    {
        if (i == slices)
            vertex[i] = glm::vec3(0, 0, 0); // Cone tip at origin
        else
            vertex[i] = glm::vec3(glm::cos(angle * i), glm::sin(angle * i), 1);
    }
    // Position, normal data
    for (int i = 0; i < numVerts / 6; i++)
    {
        int pointer = i * 6;

        // Vertex positions
        verts[pointer] = vertex[i].x;
        verts[pointer + 1] = vertex[i].y;
        verts[pointer + 2] = vertex[i].z;

        // Colors
        verts[pointer + 3] = 1.0f;
        verts[pointer + 4] = 1.0f;
        verts[pointer + 5] = 1.0f;
    }
    // Index data to share position data
    for (int i = 0; i < slices; i++)
    {
        int pointer = i * triangleSize;

        indices[pointer] = i;
        indices[pointer + 1] = i + 1 < slices ? i + 1 : 0;
        indices[pointer + 2] = slices; // Cone tip vertex index
    }
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    // Create buffer for the vertex data
    glGenBuffers(1, &mesh.vbos[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    // Create buffer for the index data
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glGenBuffers(1, &mesh.vbos[1]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

// Create cube mesh, specifying height of front and back (0 to 1, default to 1)
void UCreateCubeMesh(GLMesh& mesh, float frontHeight, float backHeight)
{
    if (frontHeight < 0 || frontHeight > 1 || backHeight < 0 || backHeight > 1)
    {
        throw invalid_argument("Height must be between 0 and 1");
    }
    float fh = -1 + (frontHeight * 2), bh = -1 + (backHeight * 2);

    GLfloat verts[] = {
     // Positions               // Colors          //Textures Coordinates
     // --------------------------------------------------------------
     // Back Face                                
    -1.0f, -1.0f, -1.0f,      0.0f,  0.0f, 0.0f,     0.0f, 0.0f,
     1.0f, -1.0f, -1.0f,      0.0f,  0.0f, 0.0f,     0.0f, 0.0f,
     1.0f,  bh,   -1.0f,      0.0f,  0.0f, 0.0f,     0.0f, 0.0f,
     1.0f,  bh,   -1.0f,      0.0f,  0.0f, 0.0f,     0.0f, 0.0f,
    -1.0f,  bh,   -1.0f,      0.0f,  0.0f, 0.0f,     0.0f, 0.0f,
    -1.0f, -1.0f, -1.0f,      0.0f,  0.0f, 0.0f,     0.0f, 0.0f,

     // Front Face                  
    -1.0f, -1.0f,  1.0f,      0.0f,  0.0f,  1.0f,    0.0f, 0.0f,
     1.0f, -1.0f,  1.0f,      0.0f,  0.0f,  1.0f,    1.0f, 0.0f,
     1.0f,  fh,    1.0f,      0.0f,  0.0f,  1.0f,    1.0f, 1.0f,
     1.0f,  fh,    1.0f,      0.0f,  0.0f,  1.0f,    1.0f, 1.0f,
    -1.0f,  fh,    1.0f,      0.0f,  0.0f,  1.0f,    0.0f, 1.0f,
    -1.0f, -1.0f,  1.0f,      0.0f,  0.0f,  1.0f,    0.0f, 0.0f,

     // Left Face              
    -1.0f,  fh,    1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
    -1.0f,  bh,   -1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
    -1.0f, -1.0f, -1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
    -1.0f, -1.0f, -1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
    -1.0f, -1.0f,  1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
    -1.0f,  fh,    1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,

     // Right Face        
     1.0f,  fh,    1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
     1.0f,  bh,   -1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
     1.0f, -1.0f, -1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
     1.0f, -1.0f, -1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
     1.0f, -1.0f,  1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
     1.0f,  fh,    1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,

     // Bottom Face       
    -1.0f, -1.0f, -1.0f,      0.0f,  0.0f,  1.0f,    0.0f, 0.0f,
     1.0f, -1.0f, -1.0f,      0.0f,  0.0f,  1.0f,    1.0f, 0.0f,
     1.0f, -1.0f,  1.0f,      0.0f,  0.0f,  1.0f,    1.0f, 1.0f,
     1.0f, -1.0f,  1.0f,      0.0f,  0.0f,  1.0f,    1.0f, 1.0f,
    -1.0f, -1.0f,  1.0f,      0.0f,  0.0f,  1.0f,    0.0f, 1.0f,
    -1.0f, -1.0f, -1.0f,      0.0f,  0.0f,  1.0f,    0.0f, 0.0f,

     // Top Face          
    -1.0f,  bh,   -1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
     1.0f,  bh,   -1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
     1.0f,  fh,    1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
     1.0f,  fh,    1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
    -1.0f,  fh,    1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f,
    -1.0f,  bh,   -1.0f,      0.0f,  0.0f,  0.0f,    0.0f, 0.0f
    };
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nIndices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.vbos[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

// Create cylinder mesh
void UCreateCylinderMesh(GLMesh& mesh)
{
    // Set number of sections making up the cylinder
    //circle formula for circumferences divide by slices to find out how many radians per slices
    const int slices = 24;
    const float angle = 2.0f * 3.14159265358979323846f / slices;

    const int secCircOffset = slices + 1; //top and bottom circle, since +1 will offset [0 = bot, 1 = top]
    const int triangleSize = 3; //set to 3 since each triangle require 3 vertices

    glm::vec3 vertex[(slices + 1) * 2];
    glm::vec2 texCoords[(slices + 1) * 2]; // Custom texture coordinates

    const int numVerts = sizeof(vertex) / sizeof(vertex[0]) * 8;
    const int numIndices = slices * triangleSize * 4;

    GLfloat verts[numVerts];
    GLushort indices[numIndices];

    for (int i = 0; i <= slices; i++)
    {
        if (i == slices)
        {
            vertex[i] = glm::vec3(0, 0, 1);
            vertex[i + secCircOffset] = glm::vec3(0, 0, -1);
        }
        else
        {
            vertex[i] = glm::vec3(glm::cos(angle * i), glm::sin(angle * i), 1);
            vertex[i + secCircOffset] = glm::vec3(glm::cos(angle * i), glm::sin(angle * i), -1);
        }

        // Custom texture coordinates
        float u = static_cast<float>(i) / slices;
        texCoords[i] = glm::vec2(u, 0.0f);                     // Top circle texture coordinates
        texCoords[i + secCircOffset] = glm::vec2(u, 1.0f);      // Bottom circle texture coordinates
    }

    // Position, normal, and texture data
    for (int i = 0; i < numVerts / 8; i++)
    {
        int pointer = i * 8;

        // Vertex positions
        verts[pointer] = vertex[i].x;
        verts[pointer + 1] = vertex[i].y;
        verts[pointer + 2] = vertex[i].z;

        // Color
        verts[pointer + 3] = vertex[i].x;
        verts[pointer + 4] = vertex[i].y;
        verts[pointer + 5] = vertex[i].z;

        // Texture
        verts[pointer + 6] = texCoords[i].x;
        verts[pointer + 7] = texCoords[i].y;
    }

    // Index data to share position data
    for (int i = 0; i < slices; i++)
    {
        int pointer = i * triangleSize;

        indices[pointer] = i;
        indices[pointer + 1] = slices;
        indices[pointer + 2] = i + 1 < slices ? i + 1 : 0;

        pointer += slices * triangleSize;

        indices[pointer] = i + secCircOffset;
        indices[pointer + 1] = slices + secCircOffset;
        indices[pointer + 2] = i + 1 < slices ? i + 1 + secCircOffset : secCircOffset;

        pointer += slices * triangleSize;

        indices[pointer] = i;
        indices[pointer + 1] = i + secCircOffset;
        indices[pointer + 2] = i + 1 < slices ? i + 1 : 0;

        pointer += slices * triangleSize;

        indices[pointer] = i + secCircOffset;
        indices[pointer + 1] = i + 1 < slices ? i + 1 : 0;
        indices[pointer + 2] = i + 1 < slices ? i + 1 + secCircOffset : secCircOffset;
    }
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao); // We can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV); // The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}


// Create plane mesh (default angle set to 0)
void UCreatePlaneMesh(GLMesh& mesh, float frontHeight, float backHeight)
{
    if (frontHeight < 0 || frontHeight > 1 || backHeight < 0 || backHeight > 1)
    {
        throw invalid_argument("Height must be between 0 and 1");
    }
    float fh = -1 + (frontHeight * 2), bh = -1 + (backHeight * 2);

    GLfloat verts[] = {
        // Positions        // Colors             //Textures
        // -------------------------------------------------
       -1.0f,  fh,  1.0f,   0.0f,  1.0f,  0.0f,   0.0f, 1.0f, // Index 0 - top left
        1.0f,  fh,  1.0f,   0.0f,  1.0f,  0.0f,   1.0f, 1.0f, // Index 1 - top right
        1.0f,  bh, -1.0f,   0.0f,  1.0f,  0.0f,   1.0f, 0.0f, // Index 2 - bottom right
       -1.0f,  bh, -1.0f,   0.0f,  1.0f,  0.0f,   0.0f, 0.0f, // Index 3 - bottom left
    };

    // Index data to share position data
    GLushort indices[] = {
        0, 1, 3,  // Triangle 1
        1, 2, 3   // Triangle 2
    };
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao); // We can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV); // The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

// Create pyramid mesh
void UCreatePyramidMesh(GLMesh& mesh)
{
    // Position and Color data for Pyramid
    GLfloat verts[] = {
        // Vertex Positions     // Textures
     -1.0f, 0.0f, -1.0f,        0.0f, 0.0f, // Left  Bot Vertex 0 || bot left  texture
      1.0f, 0.0f, -1.0f,        1.0f, 0.0f, // Right Bot Vertex 1 || bot right texture
      1.0f, 0.0f,  1.0f,        1.0f, 1.0f, // Right Top Vertex 2 || top right texture
     -1.0f, 0.0f,  1.0f,        0.0f, 1.0f, // Left  Top Vertex 3 || top left  texture

      0.0f, 1.5f, 0.0f,         0.5f, 0.5f, // Apex ORIG Vertex 4 || center of texture - Adjust height of pyramid by changing y-axis value
    };
    // Index data to share position data for pyramid
    GLushort indices[] = {
        // Base triangles
        0, 1, 2,  // Triangle 1
        0, 2, 3,  // Triangle 2

        // Side triangles
        4, 0, 1,  // Triangle 3
        4, 1, 2,  // Triangle 4
        4, 2, 3,  // Triangle 5
        4, 3, 0   // Triangle 6
    };
    const GLuint floatsPerVertex = 3;
    //const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao); // We can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV); // The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);


    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);
}

void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}
// Generate and load the texture (defaults to flipping image)
bool UCreateTexture(const char* filename, GLuint& textureId, bool flipImage)
{
    //define variables
    int width, height, channels;
    //load by file name and read variables stored in image pointer
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0); 
    if (image)
    {
        if (flipImage) //if true flip image vertically
        {
            flipImageVertically(image, width, height, channels);
        }
        //generate new texture and bind it
        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters || repeat in both the S (horizontal) and T (vertical) directions when the texture coordinates exceed the range [0, 1].
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters || linear interpolation will be used when sampling the texture.
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
        {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        }
        else if (channels == 4)
        {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        }
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }
        //Mipmaps are pre-calculated, lower-resolution versions of the texture used for efficient texture filtering.
        glGenerateMipmap(GL_TEXTURE_2D);

        //free image data stored in pointer
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture = no further modification of texture object

        return true; //if load success will return true
    }
    // Error loading the image
    return false;
}

void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}

// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // Compile the vertex shader
    // Check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // Compile the fragment shader
    // Check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId); // Links the shader program
    // Check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << endl;

        return false;
    }

    glUseProgram(programId); // Uses the shader program

    return true; //set start shader if load successfully
}

void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}
